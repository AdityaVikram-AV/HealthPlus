import React from "react";
import { BottomNav } from "./BottomNav";

interface MobileLayoutProps {
  children: React.ReactNode;
  hideBottomNav?: boolean;
}

export const MobileLayout: React.FC<MobileLayoutProps> = ({ children, hideBottomNav = false }) => {
  return (
    <div className="mobile-container bg-background">
      <div className="safe-area-top safe-area-bottom hide-scrollbar overflow-y-auto min-h-screen">
        {children}
      </div>
      {!hideBottomNav && <BottomNav />}
    </div>
  );
};

import { Clock, BookOpen } from "lucide-react";

interface ArticleCardProps {
  title: string;
  category: string;
  readTime: string;
  imageUrl?: string;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  title,
  category,
  readTime,
}) => {
  return (
    <div className="flex gap-3 bg-card rounded-2xl p-3 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98]">
      <div className="w-20 h-20 rounded-xl gradient-health shrink-0 flex items-center justify-center">
        <BookOpen className="w-8 h-8 text-primary-foreground" />
      </div>
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <span className="text-xs font-medium text-primary mb-1">{category}</span>
        <h4 className="font-semibold text-sm text-foreground line-clamp-2 mb-2">
          {title}
        </h4>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3.5 h-3.5" />
          <span>{readTime}</span>
        </div>
      </div>
    </div>
  );
};

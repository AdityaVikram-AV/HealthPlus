import { Calendar, MapPin, ChevronRight } from "lucide-react";

interface Appointment {
  id: string;
  doctorName: string;
  specialty: string;
  hospital: string;
  date: string;
  time: string;
  imageUrl?: string;
}

interface UpcomingAppointmentCardProps {
  appointment: Appointment;
}

export const UpcomingAppointmentCard: React.FC<UpcomingAppointmentCardProps> = ({
  appointment,
}) => {
  return (
    <div className="bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98]">
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl gradient-health flex items-center justify-center text-primary-foreground font-bold text-lg shrink-0">
          {appointment.doctorName.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-foreground truncate">
            {appointment.doctorName}
          </h4>
          <p className="text-sm text-muted-foreground">{appointment.specialty}</p>

          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="w-3.5 h-3.5" />
              <span>
                {appointment.date}, {appointment.time}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
            <MapPin className="w-3.5 h-3.5" />
            <span className="truncate">{appointment.hospital}</span>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
      </div>
    </div>
  );
};

import { Activity, Heart, Droplets, Moon } from "lucide-react";

interface HealthMetric {
  icon: React.ElementType;
  label: string;
  value: string;
  unit: string;
  color: string;
  bgColor: string;
}

const metrics: HealthMetric[] = [
  {
    icon: Activity,
    label: "Steps",
    value: "8,432",
    unit: "steps",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Heart,
    label: "Heart Rate",
    value: "72",
    unit: "bpm",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Droplets,
    label: "Water",
    value: "6",
    unit: "glasses",
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
  },
  {
    icon: Moon,
    label: "Sleep",
    value: "7.5",
    unit: "hrs",
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
  },
];

export const HealthInsightsCard = () => {
  return (
    <div className="bg-card rounded-3xl p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-foreground">Today's Health</h3>
        <span className="text-xs text-muted-foreground">View All</span>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {metrics.map((metric) => (
          <div key={metric.label} className="flex flex-col items-center text-center">
            <div className={`p-2.5 rounded-xl ${metric.bgColor} mb-2`}>
              <metric.icon className={`w-5 h-5 ${metric.color}`} />
            </div>
            <span className="text-lg font-bold text-foreground">{metric.value}</span>
            <span className="text-[10px] text-muted-foreground">{metric.unit}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

import { Link } from "react-router-dom";
import { Stethoscope, Pill, TestTube, Video } from "lucide-react";

const actions = [
  {
    icon: Stethoscope,
    label: "Appointments",
    description: "Book a doctor",
    color: "text-primary",
    bgColor: "bg-primary/10",
    path: "/services",
  },
  {
    icon: Pill,
    label: "Medicines",
    description: "Order now",
    color: "text-accent",
    bgColor: "bg-accent/10",
    path: "/services",
  },
  {
    icon: TestTube,
    label: "Lab Tests",
    description: "Book tests",
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
    path: "/services",
  },
  {
    icon: Video,
    label: "Video Call",
    description: "Consult online",
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
    path: "/services",
  },
];

export const QuickActionsGrid = () => {
  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((action) => (
        <Link
          key={action.label}
          to={action.path}
          className="flex flex-col items-center text-center p-3 rounded-2xl bg-card shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.95]"
        >
          <div className={`p-3 rounded-xl ${action.bgColor} mb-2`}>
            <action.icon className={`w-6 h-6 ${action.color}`} />
          </div>
          <span className="text-xs font-semibold text-foreground">{action.label}</span>
        </Link>
      ))}
    </div>
  );
};

import { Coins, TrendingUp, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

interface CoinBalanceCardProps {
  balance: number;
  redeemed: number;
  tier: "Bronze" | "Silver" | "Gold" | "Platinum";
}

const tierColors = {
  Bronze: "from-amber-600 to-amber-700",
  Silver: "from-slate-400 to-slate-500",
  Gold: "from-yellow-400 to-amber-500",
  Platinum: "from-purple-500 to-violet-600",
};

const tierBadgeColors = {
  Bronze: "bg-amber-100 text-amber-700",
  Silver: "bg-slate-100 text-slate-600",
  Gold: "bg-yellow-100 text-yellow-700",
  Platinum: "bg-purple-100 text-purple-700",
};

export const CoinBalanceCard: React.FC<CoinBalanceCardProps> = ({
  balance,
  redeemed,
  tier,
}) => {
  return (
    <Link to="/coins" className="block">
      <div
        className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${tierColors[tier]} p-5 text-primary-foreground shadow-lg transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98]`}
      >
        {/* Decorative circles */}
        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary-foreground/10" />
        <div className="absolute -bottom-12 -left-12 h-40 w-40 rounded-full bg-primary-foreground/5" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-primary-foreground/20 backdrop-blur-sm">
                <Coins className="w-5 h-5" />
              </div>
              <span className="font-semibold">Coin Balance</span>
            </div>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold ${tierBadgeColors[tier]}`}
            >
              {tier}
            </span>
          </div>

          <div className="mb-4">
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-bold">{balance.toLocaleString()}</span>
              <span className="text-sm opacity-80">coins</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5 text-sm opacity-90">
                <TrendingUp className="w-4 h-4" />
                <span>{redeemed} redeemed</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 opacity-70" />
          </div>
        </div>
      </div>
    </Link>
  );
};

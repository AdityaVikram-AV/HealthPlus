import { Trophy, Users, Clock, Coins } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ChallengeCardProps {
  title: string;
  description: string;
  progress: number;
  participants: number;
  daysLeft: number;
  coinsReward: number;
  variant?: "default" | "coral" | "purple";
}

const variantStyles = {
  default: "gradient-health",
  coral: "gradient-coral",
  purple: "gradient-purple",
};

export const ChallengeCard: React.FC<ChallengeCardProps> = ({
  title,
  description,
  progress,
  participants,
  daysLeft,
  coinsReward,
  variant = "default",
}) => {
  return (
    <div className="bg-card rounded-2xl p-4 shadow-sm min-w-[280px] transition-all duration-300 hover:shadow-md active:scale-[0.98]">
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-xl ${variantStyles[variant]}`}>
          <Trophy className="w-5 h-5 text-primary-foreground" />
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-secondary">
          <Coins className="w-3.5 h-3.5 text-tier-gold" />
          <span className="text-xs font-semibold text-secondary-foreground">
            +{coinsReward}
          </span>
        </div>
      </div>

      <h4 className="font-semibold text-foreground mb-1">{title}</h4>
      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
        {description}
      </p>

      <div className="mb-3">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-muted-foreground">Progress</span>
          <span className="text-xs font-semibold text-foreground">{progress}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Users className="w-3.5 h-3.5" />
          <span>{participants} joined</span>
        </div>
        <div className="flex items-center gap-1">
          <Clock className="w-3.5 h-3.5" />
          <span>{daysLeft} days left</span>
        </div>
      </div>
    </div>
  );
};

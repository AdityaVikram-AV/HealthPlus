import { ArrowLeft, FileText, Pill, Syringe, Shield, Calendar, ChevronRight, Upload, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { Button } from "@/components/ui/button";

const recordCategories = [
  {
    icon: FileText,
    title: "Medical History",
    count: 12,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Pill,
    title: "Medications",
    count: 5,
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Syringe,
    title: "Vaccinations",
    count: 8,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
  },
  {
    icon: Shield,
    title: "Insurance",
    count: 2,
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
  },
];

const recentRecords = [
  {
    title: "Blood Test Report",
    type: "Lab Report",
    date: "10th July, 2024",
    doctor: "Dr. Ravi Verma",
    icon: "🧪",
  },
  {
    title: "Chest X-Ray",
    type: "Imaging",
    date: "5th July, 2024",
    doctor: "Dr. Priya Singh",
    icon: "📷",
  },
  {
    title: "Prescription",
    type: "Medication",
    date: "1st July, 2024",
    doctor: "Dr. Gokul Sharma",
    icon: "💊",
  },
];

const upcomingVaccinations = [
  {
    name: "Flu Shot",
    dueDate: "15th August, 2024",
    status: "Due Soon",
  },
  {
    name: "COVID Booster",
    dueDate: "20th September, 2024",
    status: "Upcoming",
  },
];

const insuranceInfo = {
  provider: "Star Health Insurance",
  policyNumber: "SHI-2024-XXXXXX",
  coverage: "₹5,00,000",
  validTill: "31st March, 2025",
  claimsUsed: "₹45,000",
};

const RecordsPage = () => {
  return (
    <MobileLayout>
      <div className="px-4 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link to="/" className="p-2 rounded-xl bg-card shadow-sm">
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </Link>
            <h1 className="text-xl font-bold text-foreground">Health Records</h1>
          </div>
          <Button variant="outline" size="iconSm">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {/* Upload Banner */}
        <div className="bg-secondary rounded-2xl p-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-primary/10">
              <Upload className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-foreground text-sm">Upload Records</h4>
              <p className="text-xs text-muted-foreground">
                Keep all your health records in one place
              </p>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </div>
        </div>

        {/* Record Categories */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {recordCategories.map((category) => (
            <div
              key={category.title}
              className="bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98] cursor-pointer"
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`p-2 rounded-xl ${category.bgColor}`}>
                  <category.icon className={`w-5 h-5 ${category.color}`} />
                </div>
                <span className="text-xl font-bold text-foreground">{category.count}</span>
              </div>
              <h4 className="font-medium text-foreground text-sm">{category.title}</h4>
            </div>
          ))}
        </div>

        {/* Recent Records */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Recent Records</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>

          <div className="space-y-3">
            {recentRecords.map((record) => (
              <div
                key={record.title}
                className="flex items-center gap-3 bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98]"
              >
                <span className="text-2xl">{record.icon}</span>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground text-sm">{record.title}</h4>
                  <p className="text-xs text-muted-foreground">{record.type}</p>
                  <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    <span>{record.date}</span>
                    <span>•</span>
                    <span>{record.doctor}</span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>

        {/* Insurance Card */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Insurance</h3>
          <div className="relative overflow-hidden rounded-2xl gradient-purple p-5 text-primary-foreground shadow-md">
            <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-primary-foreground/10" />

            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="w-5 h-5" />
                <span className="font-semibold">{insuranceInfo.provider}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <p className="text-xs opacity-80">Coverage</p>
                  <p className="font-bold">{insuranceInfo.coverage}</p>
                </div>
                <div>
                  <p className="text-xs opacity-80">Valid Till</p>
                  <p className="font-bold">{insuranceInfo.validTill}</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs opacity-80">Claims Used</p>
                  <p className="font-semibold">{insuranceInfo.claimsUsed}</p>
                </div>
                <Button variant="glass" size="sm">
                  View Details
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Upcoming Vaccinations */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Upcoming Vaccinations</h3>
          <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
            {upcomingVaccinations.map((vaccine, index) => (
              <div
                key={vaccine.name}
                className={`flex items-center justify-between p-4 ${
                  index !== upcomingVaccinations.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-blue-500/10">
                    <Syringe className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground text-sm">{vaccine.name}</h4>
                    <p className="text-xs text-muted-foreground">{vaccine.dueDate}</p>
                  </div>
                </div>
                <span
                  className={`px-2 py-1 rounded-full text-xs font-medium ${
                    vaccine.status === "Due Soon"
                      ? "bg-accent/10 text-accent"
                      : "bg-primary/10 text-primary"
                  }`}
                >
                  {vaccine.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
};

export default RecordsPage;

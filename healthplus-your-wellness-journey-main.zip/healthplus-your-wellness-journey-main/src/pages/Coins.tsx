import { ArrowLeft, Coins as CoinsIcon, TrendingUp, Gift, Trophy, ShoppingBag, Users, ChevronRight, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

const tierInfo = {
  current: "Silver",
  coins: 2450,
  nextTier: "Gold",
  nextTierAt: 5000,
  progress: ((2450 - 1000) / (5000 - 1000)) * 100,
};

const earnOptions = [
  {
    icon: Trophy,
    title: "Complete Challenges",
    description: "Join fitness & wellness challenges",
    coins: "50-500",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Star,
    title: "Daily Check-ins",
    description: "Log your health metrics daily",
    coins: "10-25",
    color: "text-tier-gold",
    bgColor: "bg-yellow-100",
  },
  {
    icon: Users,
    title: "Refer Friends",
    description: "Invite friends to HealthPlus",
    coins: "200",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: ShoppingBag,
    title: "Purchase Programs",
    description: "Earn 5% back on purchases",
    coins: "Varies",
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
  },
];

const redemptionHistory = [
  { date: "14th July", type: "Medicines", amount: 20, icon: "💊" },
  { date: "8th June", type: "OPD Consultation", amount: 30, icon: "🩺" },
  { date: "7th June", type: "Lab Test", amount: 50, icon: "🧪" },
  { date: "1st June", type: "Wellness Program", amount: 100, icon: "🧘" },
];

const CoinsPage = () => {
  return (
    <MobileLayout>
      <div className="px-4 py-4">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link to="/" className="p-2 rounded-xl bg-card shadow-sm">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <h1 className="text-xl font-bold text-foreground">My Coins</h1>
        </div>

        {/* Coin Balance Card */}
        <div className="relative overflow-hidden rounded-3xl gradient-coin p-6 text-foreground shadow-coin mb-6">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary-foreground/10" />
          <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-primary-foreground/5" />

          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded-xl bg-foreground/10">
                <CoinsIcon className="w-6 h-6" />
              </div>
              <span className="font-semibold">Available Balance</span>
            </div>

            <div className="flex items-baseline gap-2 mb-6">
              <span className="text-5xl font-bold">{tierInfo.coins.toLocaleString()}</span>
              <span className="text-lg opacity-80">coins</span>
            </div>

            <div className="flex gap-3">
              <Button variant="glass" size="sm" className="flex-1">
                <Gift className="w-4 h-4 mr-1" />
                Redeem
              </Button>
              <Button variant="glass" size="sm" className="flex-1">
                <TrendingUp className="w-4 h-4 mr-1" />
                History
              </Button>
            </div>
          </div>
        </div>

        {/* Tier Progress */}
        <div className="bg-card rounded-2xl p-4 shadow-sm mb-6">
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-sm text-muted-foreground">Current Tier</span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-foreground text-lg">{tierInfo.current}</span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold">
                  {tierInfo.current}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-sm text-muted-foreground">Next Tier</span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-tier-gold text-lg">{tierInfo.nextTier}</span>
              </div>
            </div>
          </div>

          <Progress value={tierInfo.progress} className="h-3 mb-2" />

          <p className="text-xs text-muted-foreground text-center">
            Earn <span className="font-semibold text-foreground">{(tierInfo.nextTierAt - tierInfo.coins).toLocaleString()}</span> more coins to reach {tierInfo.nextTier}
          </p>
        </div>

        {/* Earn More Coins */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Earn More Coins</h3>
          <div className="space-y-3">
            {earnOptions.map((option) => (
              <div
                key={option.title}
                className="flex items-center gap-3 bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98]"
              >
                <div className={`p-3 rounded-xl ${option.bgColor}`}>
                  <option.icon className={`w-5 h-5 ${option.color}`} />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-foreground text-sm">{option.title}</h4>
                  <p className="text-xs text-muted-foreground">{option.description}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-tier-gold">+{option.coins}</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground mx-auto" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Redemption History */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Redemption History</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>
          <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
            {redemptionHistory.map((item, index) => (
              <div
                key={index}
                className={`flex items-center gap-3 p-4 ${
                  index !== redemptionHistory.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <span className="text-2xl">{item.icon}</span>
                <div className="flex-1">
                  <h4 className="font-medium text-foreground text-sm">{item.type}</h4>
                  <p className="text-xs text-muted-foreground">{item.date}</p>
                </div>
                <span className="font-semibold text-accent text-sm">-{item.amount}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
};

export default CoinsPage;

import { ArrowLeft, Edit, Bell, Shield, HelpCircle, LogOut, ChevronRight, User, Heart, Target, Award, Settings } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { Button } from "@/components/ui/button";

const userProfile = {
  name: "John Smith",
  email: "john.smith@email.com",
  phone: "+91 98765 43210",
  bloodType: "O+",
  age: 32,
  memberSince: "Jan 2024",
};

const healthGoals = [
  { label: "Daily Steps", current: 8432, target: 10000, unit: "steps" },
  { label: "Water Intake", current: 6, target: 8, unit: "glasses" },
  { label: "Sleep", current: 7.5, target: 8, unit: "hours" },
];

const achievements = [
  { icon: "🏃", title: "Marathon Runner", description: "Completed 30-day challenge" },
  { icon: "💧", title: "Hydration Hero", description: "7 days streak" },
  { icon: "🧘", title: "Zen Master", description: "10 meditation sessions" },
];

const menuItems = [
  { icon: User, label: "Personal Information", path: "/profile/personal" },
  { icon: Heart, label: "Health Cards", path: "/profile/health-cards" },
  { icon: Target, label: "Health Goals", path: "/profile/goals" },
  { icon: Bell, label: "Notifications", path: "/profile/notifications" },
  { icon: Shield, label: "Privacy & Security", path: "/profile/security" },
  { icon: Settings, label: "App Settings", path: "/profile/settings" },
  { icon: HelpCircle, label: "User Guide", path: "/user-guide" },
];

const ProfilePage = () => {
  return (
    <MobileLayout>
      <div className="px-4 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link to="/" className="p-2 rounded-xl bg-card shadow-sm">
              <ArrowLeft className="w-5 h-5 text-foreground" />
            </Link>
            <h1 className="text-xl font-bold text-foreground">Profile</h1>
          </div>
          <Button variant="ghost" size="iconSm">
            <Edit className="w-4 h-4" />
          </Button>
        </div>

        {/* Profile Card */}
        <div className="bg-card rounded-3xl p-5 shadow-sm mb-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-2xl gradient-health flex items-center justify-center text-primary-foreground text-3xl font-bold">
              {userProfile.name.charAt(0)}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-foreground">{userProfile.name}</h2>
              <p className="text-sm text-muted-foreground">{userProfile.email}</p>
              <div className="flex items-center gap-3 mt-2">
                <span className="px-2 py-1 rounded-full bg-accent/10 text-accent text-xs font-medium">
                  {userProfile.bloodType}
                </span>
                <span className="text-xs text-muted-foreground">
                  Member since {userProfile.memberSince}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Health Goals Progress */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Today's Goals</h3>
          <div className="bg-card rounded-2xl p-4 shadow-sm">
            <div className="space-y-4">
              {healthGoals.map((goal) => {
                const progress = (goal.current / goal.target) * 100;
                return (
                  <div key={goal.label}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm font-medium text-foreground">{goal.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {goal.current}/{goal.target} {goal.unit}
                      </span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full gradient-health rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Recent Achievements</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar -mx-4 px-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.title}
                className="min-w-[140px] bg-card rounded-2xl p-4 shadow-sm text-center"
              >
                <span className="text-3xl mb-2 block">{achievement.icon}</span>
                <h4 className="font-semibold text-foreground text-sm mb-1">
                  {achievement.title}
                </h4>
                <p className="text-[10px] text-muted-foreground">{achievement.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Menu Items */}
        <div className="mb-6">
          <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
            {menuItems.map((item, index) => (
              <div
                key={item.label}
                className={`flex items-center gap-3 p-4 transition-colors hover:bg-muted/50 cursor-pointer ${
                  index !== menuItems.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div className="p-2 rounded-xl bg-muted">
                  <item.icon className="w-5 h-5 text-foreground" />
                </div>
                <span className="flex-1 font-medium text-foreground text-sm">{item.label}</span>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>

        {/* Logout */}
        <Button variant="outline" className="w-full text-destructive border-destructive/30 hover:bg-destructive/10 hover:text-destructive">
          <LogOut className="w-4 h-4 mr-2" />
          Log Out
        </Button>
      </div>
    </MobileLayout>
  );
};

export default ProfilePage;

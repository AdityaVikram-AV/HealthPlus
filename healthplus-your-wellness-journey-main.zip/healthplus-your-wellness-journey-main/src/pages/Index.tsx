import { Bell, Search, MapPin } from "lucide-react";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { CoinBalanceCard } from "@/components/home/CoinBalanceCard";
import { HealthInsightsCard } from "@/components/home/HealthInsightsCard";
import { QuickActionsGrid } from "@/components/home/QuickActionsGrid";
import { UpcomingAppointmentCard } from "@/components/home/UpcomingAppointmentCard";
import { ChallengeCard } from "@/components/home/ChallengeCard";
import { ArticleCard } from "@/components/home/ArticleCard";

const mockAppointment = {
  id: "1",
  doctorName: "Dr. Ravi Verma",
  specialty: "General Physician",
  hospital: "Fortis Hospital, New Delhi",
  date: "14th July",
  time: "10:30 AM",
};

const mockChallenges = [
  {
    title: "30-Day Fitness Challenge",
    description: "Walk 10,000 steps daily for 30 days straight",
    progress: 65,
    participants: 2847,
    daysLeft: 12,
    coinsReward: 500,
    variant: "default" as const,
  },
  {
    title: "Hydration Hero",
    description: "Drink 8 glasses of water every day this week",
    progress: 85,
    participants: 1234,
    daysLeft: 3,
    coinsReward: 150,
    variant: "coral" as const,
  },
  {
    title: "Mindfulness Month",
    description: "Complete 15 minutes of meditation daily",
    progress: 40,
    participants: 892,
    daysLeft: 18,
    coinsReward: 300,
    variant: "purple" as const,
  },
];

const mockArticles = [
  {
    title: "10 Easy Mediterranean Diet Recipes for Beginners",
    category: "Nutrition",
    readTime: "5 min read",
  },
  {
    title: "How to Improve Your Sleep Quality Tonight",
    category: "Wellness",
    readTime: "3 min read",
  },
];

const Index = () => {
  return (
    <MobileLayout>
      <div className="px-4 py-4 stagger-children">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>New Delhi, India</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">
              Welcome, <span className="text-gradient-health">John!</span>
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2.5 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
              <Search className="w-5 h-5 text-muted-foreground" />
            </button>
            <button className="p-2.5 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow relative">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-accent" />
            </button>
          </div>
        </div>

        {/* Coin Balance */}
        <div className="mb-5">
          <CoinBalanceCard balance={2450} redeemed={550} tier="Silver" />
        </div>

        {/* Health Insights */}
        <div className="mb-5">
          <HealthInsightsCard />
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Quick Actions</h3>
          <QuickActionsGrid />
        </div>

        {/* Upcoming Appointment */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Upcoming Appointment</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>
          <UpcomingAppointmentCard appointment={mockAppointment} />
        </div>

        {/* Active Challenges */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Active Challenges</h3>
            <span className="text-xs text-primary font-medium">See All</span>
          </div>
          <div className="flex gap-3 overflow-x-auto hide-scrollbar -mx-4 px-4">
            {mockChallenges.map((challenge, index) => (
              <ChallengeCard key={index} {...challenge} />
            ))}
          </div>
        </div>

        {/* Health Articles */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Health Tips</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>
          <div className="space-y-3">
            {mockArticles.map((article, index) => (
              <ArticleCard key={index} {...article} />
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
};

export default Index;

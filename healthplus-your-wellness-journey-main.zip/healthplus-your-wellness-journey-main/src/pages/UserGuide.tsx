import { ArrowLeft, Coins, Heart, Trophy, ShoppingBag, FileText, User, ChevronDown, Zap, Target, Gift, Stethoscope } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const guideTopics = [
  {
    id: "getting-started",
    icon: Zap,
    title: "Getting Started",
    content: [
      {
        subtitle: "Welcome to HealthPlus!",
        text: "HealthPlus is your all-in-one health companion that rewards you for staying healthy. Track your health goals, earn coins through healthy activities, and redeem them for exciting health products and services."
      },
      {
        subtitle: "Creating Your Profile",
        text: "Set up your profile with your health information including blood type, age, and health goals. This helps us personalize your experience and track your progress effectively."
      }
    ]
  },
  {
    id: "earning-coins",
    icon: Coins,
    title: "Earning Coins",
    content: [
      {
        subtitle: "How to Earn",
        text: "Earn coins by completing daily health activities like walking 10,000 steps, drinking 8 glasses of water, getting enough sleep, and participating in wellness challenges."
      },
      {
        subtitle: "Challenge Bonuses",
        text: "Join organizational challenges to earn bonus coins. Complete challenges within the deadline to get extra rewards and compete on leaderboards."
      },
      {
        subtitle: "Streak Rewards",
        text: "Maintain daily streaks for bonus coins. The longer your streak, the higher your daily multiplier!"
      }
    ]
  },
  {
    id: "spending-coins",
    icon: Gift,
    title: "Spending Coins",
    content: [
      {
        subtitle: "Health Products",
        text: "Use your coins to purchase fitness equipment, supplements, healthy food items, and wellness products from our curated marketplace."
      },
      {
        subtitle: "Health Programs",
        text: "Redeem coins for premium wellness programs including yoga classes, meditation sessions, nutrition consultations, and fitness coaching."
      },
      {
        subtitle: "OPD Services",
        text: "Apply your coins toward OPD consultations and wellness treatments at partner healthcare providers."
      }
    ]
  },
  {
    id: "challenges",
    icon: Trophy,
    title: "Challenges & Competitions",
    content: [
      {
        subtitle: "Types of Challenges",
        text: "Participate in step challenges, hydration goals, sleep tracking competitions, and team-based wellness events organized by your company."
      },
      {
        subtitle: "Leaderboards",
        text: "Compete with colleagues and friends. Top performers earn special badges and bonus coin rewards at the end of each challenge."
      },
      {
        subtitle: "Team Challenges",
        text: "Join team-based challenges to earn collective rewards. Encourage your teammates and achieve goals together!"
      }
    ]
  },
  {
    id: "health-tracking",
    icon: Heart,
    title: "Health Tracking",
    content: [
      {
        subtitle: "Daily Goals",
        text: "Set and track daily goals for steps, water intake, sleep, and exercise. Complete all goals to earn your daily bonus coins."
      },
      {
        subtitle: "Health Insights",
        text: "View detailed analytics of your health metrics over time. Track trends in your BMI, heart rate, and activity levels."
      },
      {
        subtitle: "Sync Devices",
        text: "Connect your fitness trackers and smartwatches to automatically sync your health data and earn coins seamlessly."
      }
    ]
  },
  {
    id: "services",
    icon: Stethoscope,
    title: "Health Services",
    content: [
      {
        subtitle: "OPD Coverage",
        text: "Access outpatient services at partner hospitals and clinics. Book appointments directly through the app and use your benefits."
      },
      {
        subtitle: "IPD Tracking",
        text: "Monitor your inpatient insurance coverage, view policy details, and track claims all in one place."
      },
      {
        subtitle: "Wellness Programs",
        text: "Explore and enroll in various wellness programs designed to improve your physical and mental health."
      }
    ]
  },
  {
    id: "records",
    icon: FileText,
    title: "Health Records",
    content: [
      {
        subtitle: "Document Storage",
        text: "Securely store all your medical documents, prescriptions, lab reports, and health certificates in one place."
      },
      {
        subtitle: "Easy Access",
        text: "Access your records anytime, anywhere. Share documents with healthcare providers directly from the app."
      },
      {
        subtitle: "Auto-Organization",
        text: "Records are automatically organized by type and date for easy retrieval when you need them."
      }
    ]
  },
  {
    id: "profile",
    icon: User,
    title: "Profile & Settings",
    content: [
      {
        subtitle: "Personal Information",
        text: "Update your contact details, emergency contacts, and health information to keep your profile current."
      },
      {
        subtitle: "Notifications",
        text: "Customize notification preferences for challenges, health reminders, and promotional offers."
      },
      {
        subtitle: "Privacy",
        text: "Control who can see your health data and challenge participation. Your data security is our priority."
      }
    ]
  }
];

const quickTips = [
  "Complete your daily goals before midnight to maintain your streak",
  "Join at least one challenge per month to maximize coin earnings",
  "Sync your fitness device for automatic activity tracking",
  "Check the rewards shop weekly for limited-time offers",
  "Set reminders for water intake and movement breaks"
];

const UserGuidePage = () => {
  return (
    <MobileLayout hideBottomNav>
      <div className="px-4 py-4 pb-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Link to="/profile" className="p-2 rounded-xl bg-card shadow-sm">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <h1 className="text-xl font-bold text-foreground">User Guide</h1>
        </div>

        {/* Hero Section */}
        <div className="bg-gradient-to-br from-primary to-accent rounded-3xl p-5 mb-6 text-primary-foreground">
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-white/20 rounded-xl">
              <Heart className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold">Welcome to HealthPlus</h2>
          </div>
          <p className="text-sm opacity-90 leading-relaxed">
            Your complete guide to earning coins, staying healthy, and unlocking amazing rewards. Let's get you started on your wellness journey!
          </p>
        </div>

        {/* Quick Tips */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Quick Tips
          </h3>
          <div className="bg-card rounded-2xl p-4 shadow-sm">
            <ul className="space-y-3">
              {quickTips.map((tip, index) => (
                <li key={index} className="flex items-start gap-3 text-sm">
                  <span className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <span className="text-muted-foreground">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Guide Topics */}
        <div className="mb-6">
          <h3 className="font-semibold text-foreground mb-3">Complete Guide</h3>
          <Accordion type="single" collapsible className="space-y-3">
            {guideTopics.map((topic) => (
              <AccordionItem
                key={topic.id}
                value={topic.id}
                className="bg-card rounded-2xl shadow-sm border-none overflow-hidden"
              >
                <AccordionTrigger className="px-4 py-3 hover:no-underline [&[data-state=open]]:bg-muted/30">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-primary/10">
                      <topic.icon className="w-5 h-5 text-primary" />
                    </div>
                    <span className="font-semibold text-foreground text-sm">{topic.title}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                  <div className="space-y-4 pt-2">
                    {topic.content.map((section, idx) => (
                      <div key={idx}>
                        <h4 className="font-medium text-foreground text-sm mb-1">{section.subtitle}</h4>
                        <p className="text-xs text-muted-foreground leading-relaxed">{section.text}</p>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Need Help */}
        <div className="bg-muted/50 rounded-2xl p-4 text-center">
          <p className="text-sm text-muted-foreground mb-2">Still have questions?</p>
          <Link 
            to="/profile" 
            className="text-primary font-medium text-sm hover:underline"
          >
            Contact Support →
          </Link>
        </div>
      </div>
    </MobileLayout>
  );
};

export default UserGuidePage;

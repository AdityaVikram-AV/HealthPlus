import { ArrowLeft, Search, Stethoscope, Pill, TestTube, Video, MapPin, Star, ChevronRight, Clock, Coins } from "lucide-react";
import { Link } from "react-router-dom";
import { MobileLayout } from "@/components/layout/MobileLayout";
import { Button } from "@/components/ui/button";

const serviceCategories = [
  {
    icon: Stethoscope,
    title: "Appointments",
    description: "Book doctor visits",
    color: "text-primary",
    bgColor: "bg-primary/10",
    gradient: "gradient-health",
  },
  {
    icon: Pill,
    title: "Medicines",
    description: "Order medicines",
    color: "text-accent",
    bgColor: "bg-accent/10",
    gradient: "gradient-coral",
  },
  {
    icon: TestTube,
    title: "Lab Tests",
    description: "Book health tests",
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
    gradient: "bg-gradient-to-br from-blue-500 to-blue-600",
  },
  {
    icon: Video,
    title: "Video Consult",
    description: "Online consultation",
    color: "text-violet-500",
    bgColor: "bg-violet-500/10",
    gradient: "gradient-purple",
  },
];

const recentDoctors = [
  {
    name: "Dr. Ravi Verma",
    specialty: "General Physician",
    hospital: "Fortis Hospital, New Delhi",
    rating: 4.8,
    reviews: 234,
    nextSlot: "Today, 2:00 PM",
    coinDiscount: 30,
  },
  {
    name: "Dr. Gokul Sharma",
    specialty: "Cardiologist",
    hospital: "Max Hospital, New Delhi",
    rating: 4.9,
    reviews: 189,
    nextSlot: "Tomorrow, 10:00 AM",
    coinDiscount: 50,
  },
  {
    name: "Dr. Priya Singh",
    specialty: "Dermatologist",
    hospital: "Apollo Hospital, Gurgaon",
    rating: 4.7,
    reviews: 156,
    nextSlot: "Today, 5:30 PM",
    coinDiscount: 25,
  },
];

const popularTests = [
  { name: "Complete Blood Count", price: "₹399", coinPrice: 200, discount: "50%" },
  { name: "Thyroid Profile", price: "₹599", coinPrice: 300, discount: "50%" },
  { name: "Vitamin D Test", price: "₹799", coinPrice: 400, discount: "50%" },
];

const ServicesPage = () => {
  return (
    <MobileLayout>
      <div className="px-4 py-4">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <Link to="/" className="p-2 rounded-xl bg-card shadow-sm">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <h1 className="text-xl font-bold text-foreground">Services</h1>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search doctors, hospitals, tests..."
            className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
          />
        </div>

        {/* Service Categories */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {serviceCategories.map((service) => (
            <div
              key={service.title}
              className="bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98] cursor-pointer"
            >
              <div className={`w-12 h-12 rounded-xl ${service.gradient} flex items-center justify-center mb-3`}>
                <service.icon className="w-6 h-6 text-primary-foreground" />
              </div>
              <h4 className="font-semibold text-foreground">{service.title}</h4>
              <p className="text-xs text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>

        {/* Recent Doctors */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Doctors You've Consulted</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>

          <div className="space-y-3">
            {recentDoctors.map((doctor) => (
              <div
                key={doctor.name}
                className="bg-card rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md active:scale-[0.98]"
              >
                <div className="flex items-start gap-3">
                  <div className="w-14 h-14 rounded-xl gradient-health flex items-center justify-center text-primary-foreground font-bold text-xl shrink-0">
                    {doctor.name.split(" ")[1].charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-foreground">{doctor.name}</h4>
                        <p className="text-sm text-muted-foreground">{doctor.specialty}</p>
                      </div>
                      <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-secondary">
                        <Coins className="w-3 h-3 text-tier-gold" />
                        <span className="text-xs font-semibold text-secondary-foreground">
                          -{doctor.coinDiscount}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                      <MapPin className="w-3.5 h-3.5" />
                      <span className="truncate">{doctor.hospital}</span>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-tier-gold fill-tier-gold" />
                          <span className="text-xs font-semibold text-foreground">{doctor.rating}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">({doctor.reviews})</span>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-primary font-medium">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{doctor.nextSlot}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <Button variant="outline" size="sm" className="w-full mt-3">
                  Book Appointment
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Popular Lab Tests */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Popular Lab Tests</h3>
            <span className="text-xs text-primary font-medium">View All</span>
          </div>

          <div className="bg-card rounded-2xl shadow-sm overflow-hidden">
            {popularTests.map((test, index) => (
              <div
                key={test.name}
                className={`flex items-center justify-between p-4 ${
                  index !== popularTests.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div>
                  <h4 className="font-medium text-foreground text-sm">{test.name}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground line-through">{test.price}</span>
                    <div className="flex items-center gap-1">
                      <Coins className="w-3 h-3 text-tier-gold" />
                      <span className="text-xs font-semibold text-foreground">{test.coinPrice} coins</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-semibold">
                      {test.discount} OFF
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
};

export default ServicesPage;
